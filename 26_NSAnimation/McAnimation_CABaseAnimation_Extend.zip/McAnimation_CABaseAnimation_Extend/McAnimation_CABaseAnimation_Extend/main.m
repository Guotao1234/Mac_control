//
//  main.m
//  McAnimation_CABaseAnimation_Extend
//
//  Created by TanHao on 12-12-15.
//  Copyright (c) 2012年 tanhao.me. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
